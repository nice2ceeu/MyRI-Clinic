<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>MyRi Clinic.</title>
  <link href="../../src/output.css" rel="stylesheet" />
  <link href="../../src/input.css" rel="stylesheet" />
  <link rel="icon" type="/favicon.svg" href="../../view/assets/icons/school-icon.svg">
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body>