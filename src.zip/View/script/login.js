const signIn = document.getElementById("signIn-btn");

signIn.addEventListener("click", () => {
  window.location = "../pages/visitor.php";
});
