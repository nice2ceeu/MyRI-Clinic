<?php
header("Location: View/pages/index.php");
exit;
